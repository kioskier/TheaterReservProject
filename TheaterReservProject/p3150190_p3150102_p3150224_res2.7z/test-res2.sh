gcc -Wall -pthread p3150190_p3150102_p3150224_res2.c
./a.out 100 1000
