#include <stdio.h>

int Ntel=8;
int Ncash=4;
int Nseat=10;
int NzoneA=5;
int NzoneB=10;
int NzoneC=10;
int PzoneA=2;
int PzoneB=6;
int PzoneC=10;
int CzoneA=30;
int CzoneB=25;
int CzoneC=20;
int Nseatlow=1; 
int Nseathigh=5; 
int tseatlow=5;
int tseathigh=10; 
int tcashlow=2;
int tcashhigh=4;
int Pcardsuccess=9;




